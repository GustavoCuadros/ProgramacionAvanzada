#include <cstdlib>
#include <iostream>

using namespace std; /*cin, cout, endl*/

int main(int argc, char *argv[])
{
	cout<<"Hola Mundo Programacion Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
